package com.example.creditcard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CalHistory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal_history);
    }
}

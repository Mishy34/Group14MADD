package com.example.creditcard;

//import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {



    private EditText mLoanAmount, mInterestRate, mLoanPeriod;
    private TextView mMOnthlyPaymentResult, mTotalPaymentResult;
    Button calButton, calHistory;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mLoanAmount = (EditText)findViewById(R.id.loan_amount);
        calButton = findViewById(R.id.cal);
        mInterestRate = (EditText)findViewById(R.id.interest_rate);
        mLoanPeriod = (EditText)findViewById(R.id.loan_period);
        mMOnthlyPaymentResult = (TextView)findViewById(R.id.monthly_payment_result);
        mTotalPaymentResult = (TextView)findViewById(R.id.total_payment_result);
        calHistory = findViewById(R.id.calhis);

        //DBHelper myDB = new DBHelper(MainActivity.this);
        //myDB.CCCal(mLoanAmount.getText().toString().trim(),
          //      mInterestRate.getText().toString().trim(),
                //Integer.valueOf(mLoanPeriod.getText().toString().trim()),
                //Integer.valueOf(mInterestRate.getText().toString().trim()),
            //    Integer.valueOf(mLoanPeriod.getText().toString().trim()));


        calButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double loanAmount = Integer.parseInt(mLoanAmount.getText().toString());
                double interestRate = (Integer.parseInt(mInterestRate.getText().toString()));
                double loanPeriod = Integer.parseInt(mLoanPeriod.getText().toString());
                double r = interestRate/1200;
                double r1 = Math.pow(r+1,loanPeriod);

                double monthlyPatyment = (double) ((r + (r/ (r1 - 1))) * loanAmount);
                double totalPayment = monthlyPatyment * loanPeriod;

                mMOnthlyPaymentResult.setText(new DecimalFormat("##.##").format(monthlyPatyment));
                mTotalPaymentResult.setText(new DecimalFormat("##.##").format(totalPayment));




            }


        });

        calHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Intent intent = new Intent(MainActivity.this, CalHistory.class);
                startActivity(intent);



            }


        });


    }

    /*public void showLoanPayments(View clickedButton){

        double loanAmount = Integer.parseInt(mLoanAmount.getText().toString());
        double interestRate = (Integer.parseInt(mInterestRate.getText().toString()));
        double loanPeriod = Integer.parseInt(mLoanPeriod.getText().toString());
        double r = interestRate/1200;
        double r1 = Math.pow(r+1,loanPeriod);

        double monthlyPatyment = (double) ((r + (r/ (r1 - 1))) * loanAmount);
        double totalPayment = monthlyPatyment * loanPeriod;

        mMOnthlyPaymentResult.setText(new DecimalFormat("##.##").format(monthlyPatyment));
        mTotalPaymentResult.setText(new DecimalFormat("##.##").format(totalPayment));
    }*/

}
